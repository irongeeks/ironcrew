export default "<!doctype html><html lang=\"de\"><head><title>Remote build</title></head><body><h1>Native remote build</h1></body></html>";
