# React-Selbsthosting

Node 26.4.0. `node build.mjs` baut ohne Netz und ohne Paketinstallation; `node server.mjs` startet auf 127.0.0.1:3000 (PORT konfigurierbar). React und React DOM 19.2.7 sind samt MIT-Lizenz und SHA-256 vendort. `src/app.mjs` enthält die React-Komponente, `src/concept.mjs` den ausgewählten Entwurf als Daten. Ergänzungen erfolgen als JavaScript-Module mit createElement; JSX benötigt einen zusätzlich geprüften Compiler.

Vor externem Betrieb TLS-Reverse-Proxy konfigurieren. Neue Version separat bauen und prüfen, Dienst stoppen, auf neue Version wechseln, starten und HTTPS/Funktion prüfen. Alte Version für Rollback behalten. Die Buildprüfung bestätigt weder TLS noch einen Livebetrieb.
