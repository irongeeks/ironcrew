<?php
if (!defined('ABSPATH')) { exit; }
add_action('wp_enqueue_scripts', function () { wp_enqueue_style('ironcrew-customer-site', get_stylesheet_uri(), array(), '1.0.0'); });
