# WordPress-Blocktheme

Ziel: WordPress 7.0.4. `php -l theme/functions.php` prüft PHP-Syntax, `node build.mjs` mit Node 26.4.0 erstellt `dist/ironcrew-customer-site`. Diesen Themeordner in einer eigenen WordPress-Installation nach `wp-content/themes/ironcrew-customer-site` kopieren und über Design → Themes aktivieren. `dist/index.html` ist eine statische Entwurfsvorschau; sie bestätigt keinen laufenden WordPress-Server.

Datenbank, WordPress-Kern, PHP-Runtime, TLS, Backup und Zugangsdaten werden vom eigenen Hostingprofil bereitgestellt. Vor Aktivierung Datenbank und bisheriges Theme sichern. Update: neues geprüftes Theme separat bereitstellen, Sicherung anlegen, Themeversion wechseln und Startseite/Unterseiten/Admin prüfen. Rollback: vorheriges Theme wieder aktivieren, erforderlichenfalls Datenbanksicherung wiederherstellen. Zugangsdaten gehören ausschließlich in den Secretstore.
